## v0.1基础server
### 方法
1. 启动服务器
    - 基本的服务器开发 1. 创建Addr，2. 创建lisetener 3. 处理客户端基本的业务功能，回显功能
2. 运行服务器
    - 调用start()方法，调用之后做阻塞处理，在之间可以做一个扩展功能
3. 停止服务器

## V0.2 简单的链接封装和业务绑定
### 链接模块
- 方法
  - 启动链接Start()
  - 停止链接Stop()
  - 获取当前链接的conn对象(套接字)
  - 得到链接ID
  - 得到客户端链接的地址和端口
  - 发送数据的方法Send()

- 属性
  - socket TCP套接字
  - 链接ID
  - 链接状态是否关闭
  - 与当前链接绑定的业务处理方法API
  - 等待被告知关闭的channel

## 基础route模块
### Request 请求封装 
- 将链接和数据绑在一起
- 属性
  - 链接Connection
  - 请求数据
- 方法
  - 得到当前链接
  - 得到当前数据
### Route模块
- 抽象的IRouter：
  - PreHandle 处理业务之前的方法
  - Handle 处理业务的方法
  - PostHandle 处理业务之后的方法
- 实现的BaseRouter
- 集成Router模块
  - IServer 添加路由功能
  - Server 类添加Router成员
  - Connection 类绑定一个Router成员
  - Connection  调用已经注册的Router处理业务

